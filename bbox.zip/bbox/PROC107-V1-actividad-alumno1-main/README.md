# PROC107-V1-actividad-alumno1
Detección y seguimiento de objetos.  
Plantilla del alumno.  
Python. OpenCV.  
  
Lesson plan.  
  
### Texto en inglés: PRO-C107-Student-Boilerplate
PRO-C107-Student-Boilerplate